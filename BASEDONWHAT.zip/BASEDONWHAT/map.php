<head>
    ...
    <?php
    require_once("config.php");
    ?>
<style>
  #map {
    height: 400px;
    width: 80%        
  }
</style>
</head>
<body>

    <div id="map"></div>


    <?php
$result = $conn->query("SELECT * FROM Images;");
echo"
<script>

function initMap() {
  var options = {
    zoom: 15,
    center: { lat: 33.933241, lng: -84.340288 },
  };
  
  var icon = {
// url: 'uploads/ ashi.png', // url
scaledSize: new google.maps.Size(50, 50), // scaled size
origin: new google.maps.Point(0,0), // origin
anchor: new google.maps.Point(0, 0) // anchor
};
  var map = new google.maps.Map(document.getElementById('map'), options);
  var marker = new google.maps.Marker({
    position: { lat: 33.933241, lng: -84.340288 },
    scaledSize: new google.maps.Size(50, 50),
    map: map,
    icon: icon
  });
";

    while ($row = $result->fetch_assoc()) {

                  unset($id, $name);
                  $userinitials = $row['UserInitials'];
                  $lat = $row['Latitude']; 
                  $long = $row ['Longitude']; 
                  $classification = $row ['Classification']; 
                  $filename = $row ['file_name']; 
                  echo"
                  var icon = {
                    url: 'uploads/".$filename."', // url
                    scaledSize: new google.maps.Size(50, 50), // scaled size
                    origin: new google.maps.Point(0,0), // origin
                    anchor: new google.maps.Point(0, 0) // anchor
                    };
                  var marker = new google.maps.Marker({
                    position: { lat: ".$lat.", lng: ".$long." },
                    scaledSize: new google.maps.Size(50, 50),
                    map: map,
                    icon: icon
                  });
                  
                  "; 
                  
                }
                echo"} </script> ";


?>

    <script defer
          src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBWXYep52sp-CHxdm_i5WFRrYciACUyEiQ&callback=initMap">
        </script>
</body>