drop table if exists Images;
CREATE TABLE Images (
    EntryID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    UserInitials Char(2) NOT NULL,
    Latitude Double NOT NULL,
    Longitude Double NOT NULL,
	`file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
	`uploaded_on` datetime NOT NULL,
    Classification char(50) NOT NULL
)
