<html>
<head>
<?php //require_once("config.php"); ?>
    <script src="https://unpkg.com/ml5@latest/dist/ml5.min.js"></script>
    <link rel="stylesheet" href="mystyle.css">
    <meta charset="UTF-8">
    <title>Image Classification program for Beginners</title>
</head>

<form action="action_page.php" method="post" enctype="multipart/form-data">
    <input type='file' id='getval' name = "getval" accept="image/png, image/jpeg" required/>
    <input type="hidden" id = "classifier" name = "classifier" value = "bleh"/>
    <input type="text" id = "userinitials" name = "userinitials"/>
    <input type="text" id = "latitude" name = "latitude"/>
    <input type="text" id = "longitude" name = "longitude" />
    <input type="submit" value="Submit">
  </form>
<body>   
    <h1>Image classification using MobileNet model</h1>

    <img id="image" src="http://placehold.it/180" alt="your image"/>
    <p>That's <span id ="result"> </span>
              </span> with a confidence of
            <span id="probability">   </span>.
          </p>
    <script src="myscript.js"></script>

</body>

</html>