<!DOCTYPE html>
<!-- saved from url=(0066)https://comp-server.uhi.ac.uk/~17010076/Woodland%20Trust/page.html -->
<html dir="ltr" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<title>Woodland Trust</title>
	
	
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.5, user-scalable=yes">
	
	<link rel="icon" type="image/x-icon" href="Woodland%20Trust/assets/favicon.png">
	<link rel="stylesheet" type="text/css" href="./styles/default.css">
	<link rel="stylesheet" href="./Woodland Trust_files/font-awesome.min.css">
  <script src="https://unpkg.com/ml5@latest/dist/ml5.min.js"></script>
    <link rel="stylesheet" href="mystyle.css">
    <meta charset="UTF-8">
</head>

<body> 

	<nav>
		<ul>
			<li><a href="https://comp-server.uhi.ac.uk/~17010076/Woodland%20Trust/page.html#"><i class="fa fa-fw fa-home"></i>HOME</a></li>
			<li><a href="map.php"><i class="fa fa-fw fa-map-marker"></i>MAP</a></li>
			<li><a href="https://comp-server.uhi.ac.uk/~17010076/Woodland%20Trust/page.html#"><i class="fa fa-fw fa-question"></i>FAQ</a></li>
		</ul>
	</nav>
			
	<div class="top">
		<a href="https://comp-server.uhi.ac.uk/~17010076/Woodland%20Trust/page.html#"><img class="logo" src="./assets/logo.png" alt="Logo"></a>
	</div>
	
	<div class="wrapper">=
		<div class="form">
			<h2><i class="fa fa-file-image-o"></i> Upload your picture</h2>
      <form class="upload-form" action="action_page.php" method="post" enctype="multipart/form-data">
    <input type='file' id='getval' name = "getval" accept="image/png, image/jpeg" required/>
    <input type="hidden" id = "classifier" name = "classifier" value = "bleh"/>
    <input type="text" id = "userinitials" name = "userinitials"  placeholder="User initials"/>
    <input type="text" id = "latitude" name = "latitude"  placeholder="Please enter the latitude"/>
    <input type="text" id = "longitude" name = "longitude"  placeholder="Please enter the longitude" />
    <input type="submit" value="Submit">
  </form>
			</form>
		</div>
	</div>
	
	<div class="wrapper">
		<div class="main">
			<h1>What is Woodland Trust?</h1>
			<p>Woodland Trust is an online service aiding users in seeking wildlife in Scotland. Please use this service for uploading pictures from your device to our server. You only need to input picture, we will download it, our system will try to predict which animal it represents. Results will be placed on our heat-map (with your name and comment that you left). Please ensure that comment box is used for additional information that would aid others. For example: where was animal spotted exactly and when.</p>
		</div>
	</div>
  <img id="image" src="http://placehold.it/180" alt="your image"/>
    <p>That's <span id ="result"> </span>
              </span> with a confidence of
            <span id="probability">   </span>.
          </p>
    <script src="myscript.js"></script>
	<hr class="footer-hr">
	<p class="footer-font">Copyright © Woodland Trust. All rights reserved.</p>	
	

</body></html>