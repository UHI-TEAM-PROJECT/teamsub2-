<?php
/* Database credentials*/
define('DB_SERVER', 'comp-server.uhi.ac.uk');
define('DB_USERNAME', 'pe19004547');
define('DB_PASSWORD', 'ewanerskine');
define('DB_NAME', 'pe19004547');

/* Attempt to connect to MySQL database */
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>